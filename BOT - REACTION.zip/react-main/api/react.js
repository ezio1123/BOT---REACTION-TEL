// api/react.js

// NOTE: In-memory store. Ini OK buat basic, tapi di serverless bisa gak konsisten.
// Kalau mau beneran konsisten 12 jam: pindah ke Vercel KV / Redis.
const cooldownMap = new Map(); // ip -> timestamp(ms)
let rrIndex = 0; // round-robin index key

function getClientIp(req) {
  // Vercel biasanya nyediain x-forwarded-for
  const xff = req.headers["x-forwarded-for"];
  if (typeof xff === "string" && xff.length > 0) {
    return xff.split(",")[0].trim();
  }
  // fallback
  return req.socket?.remoteAddress || "unknown";
}

function isMobile(req) {
  const ua = (req.headers["user-agent"] || "").toLowerCase();
  return /android|iphone|ipad|ipod|mobile/.test(ua);
}

function getKeys() {
  const raw = process.env.CM_API_KEYS || "";
  const keys = raw
    .split(",")
    .map(s => s.trim())
    .filter(Boolean);
  return keys;
}

function pickNextKey(keys) {
  if (!keys.length) return null;
  const key = keys[rrIndex % keys.length];
  rrIndex = (rrIndex + 1) % keys.length;
  return key;
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ ok: false, error: "Method Not Allowed. Use POST." });
  }

  // (Optional) blok HP via user-agent
  if (process.env.BLOCK_MOBILE === "1" && isMobile(req)) {
    return res.status(403).json({ ok: false, error: "Access blocked for mobile devices." });
  }

  const ip = getClientIp(req);

  // Rate limit: 1 request per 12 jam per IP
  const hours = Number(process.env.COOLDOWN_HOURS || "12");
  const cooldownMs = hours * 60 * 60 * 1000;

  const now = Date.now();
  const last = cooldownMap.get(ip);
  if (last && now - last < cooldownMs) {
    const remainingMs = cooldownMs - (now - last);
    const remainingMin = Math.ceil(remainingMs / 60000);
    return res.status(429).json({
      ok: false,
      error: `Rate limit: 1 request per ${hours} hours per IP.`,
      retry_after_minutes: remainingMin,
    });
  }

  // Key rotation
  const keys = getKeys();
  if (!keys.length) {
    return res.status(500).json({
      ok: false,
      error: "CM_API_KEYS belum diset atau kosong. Isi env CM_API_KEYS=key1,key2,...",
    });
  }

  const apiKey = pickNextKey(keys);

  const upstreamUrl =
    process.env.CM_REACT_ENDPOINT ||
    "https://foreign-marna-sithaunarathnapromax-9a005c2e.koyeb.app/api/channel/react-to-post";

  // Validate body
  const body = req.body && typeof req.body === "object" ? req.body : {};
  if (!body.post_link || !body.reacts) {
    return res.status(400).json({
      ok: false,
      error: "Body harus ada post_link dan reacts",
      example: { post_link: "https://whatsapp.com/channel/.../151", reacts: "🔥,😂,🤣" },
    });
  }

  try {
    const upstreamRes = await fetch(upstreamUrl, {
      method: "POST",
      headers: {
        Accept: "application/json, text/plain, */*",
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
        Referer: "https://asitha.top/channel-manager",
      },
      body: JSON.stringify({
        post_link: body.post_link,
        reacts: body.reacts,
      }),
    });

    const text = await upstreamRes.text();

    // Kalau sukses, baru kita catat cooldown IP
    if (upstreamRes.ok) {
      cooldownMap.set(ip, now);
      // housekeeping kecil biar map gak membengkak
      if (cooldownMap.size > 5000) {
        // purge entri tua (best-effort)
        for (const [k, v] of cooldownMap.entries()) {
          if (now - v > cooldownMs) cooldownMap.delete(k);
        }
      }
    }

    res.status(upstreamRes.status);
    res.setHeader(
      "content-type",
      upstreamRes.headers.get("content-type") || "application/json; charset=utf-8"
    );

    // OPTIONAL: jangan pernah balikin apiKey ke client
    return res.send(text);
  } catch (err) {
    return res.status(500).json({ ok: false, error: err?.message || "Proxy error" });
  }
}
